package ar.edu.unlam.materia;

import static org.junit.Assert.*;

import org.junit.Test;

import ar.edu.unlam.dominio.Alumno;
import ar.edu.unlam.dominio.Inscripcion;
import ar.edu.unlam.dominio.Materia;
import ar.edu.unlam.dominio.Nota;

public class TestCursada {

	@Test
	public void crearCursada() {
		
		Alumno alumno = new Alumno(22,"Juan", "Perez");
		Materia materia = new Materia("pb2");
		Nota nota = new Nota(0);
		Inscripcion cursada = new Inscripcion(alumno, materia, nota);
		
		assertNotNull(cursada);
		
		Inscripcion cursada1 = new Inscripcion(alumno, materia);
		
		assertEquals(0, cursada1.getNota().getValor(),0.0);
	}

}
