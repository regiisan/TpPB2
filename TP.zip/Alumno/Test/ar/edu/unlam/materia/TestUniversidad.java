package ar.edu.unlam.materia;

import static org.junit.Assert.*;
import ar.edu.unlam.dominio.*;
import org.junit.Test;

public class TestUniversidad {

	// universidad inscriba al alumno
	// universidad registre materia
	// universidad inscriba alumno

	@Test
	public void quesePuedaRegistrarUnAlumnoAUnaUniversidad() {
		
		// Preparacion
		String nombre = "Unlam";
		Universidad universidad = new Universidad(nombre);
		String nombreAlumno = "Regina";
		String apellido = "Sanchez";
		Integer dni = 45870226;
		Alumno alumno = new Alumno(dni, nombreAlumno, apellido);

		// Ejecucion
		Boolean registroExitoso = universidad.registrarAlumno(alumno);
		
		// Validacion
		assertTrue(registroExitoso);
	}
	
	
	
}
