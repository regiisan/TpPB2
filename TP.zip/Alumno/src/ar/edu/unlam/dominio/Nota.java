package ar.edu.unlam.dominio;

public class Nota {

	private int valor;
	
	public Nota(int valor) {
		this.valor = valor;
	}

	public int getValor() {
		return valor;
	}

	public void setValor(int valor) {
		this.valor = valor;
	}
	
	
}

