package ar.edu.unlam.dominio;

import java.util.ArrayList;
import java.util.Iterator;

public class Universidad {

	private String nombre;
	private ArrayList<Alumno> alumnos;
	private ArrayList<Materia> materiasM;

	public Universidad(String nombre) {
		this.nombre = nombre;
		this.alumnos = new ArrayList<Alumno>();
	}

	public Boolean registrarAlumno(Alumno alumno) {
		if (buscarAlumnoPorDni(alumno.getDni()) == null) {
			return this.alumnos.add(alumno);
		}

		return false;
	}

	private Alumno buscarAlumnoPorDni(Integer dni) {
		for (int i = 0; i < alumnos.size(); i++) {
			if (this.alumnos.get(i).getDni().equals(dni)) {
				return this.alumnos.get(i);
			}
		}
		return null;
	}

//	public boolean existeAlumno(Integer dni) {
//		for (int i = 0; i < alumnos.size(); i++) {
//			if (this.alumnos.get(i).getDni().equals(dni)) {
//				return true;
//			}
//		}
//		return false;
//	}
	
	public boolean existeAlumn(Alumno buscado) {
		return this.alumnos.contains(buscado);
	}

//	public void evaluar(dni, codMateria, nota) {
//		
//		Cursada c = buscarCursada(dni, codMateria);
//	
//		if(c!= null) {
//			c.calificar();
//		}
//	}

}
